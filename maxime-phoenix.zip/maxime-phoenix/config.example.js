// Copier en config.js (ignoré par Git). Les clés réelles vont sur le serveur, jamais ici.
window.CONFIG={API_URL:'https://votre-serveur.example/api'};
