# MAXIME Phœnix

Application de création et de promotion de contenu pour les réseaux sociaux (2 PRO LUX Professionnel).
Innover · Performer · Rayonner

## Structure
- `index.html` : page principale
- `css/style.css` : styles
- `js/app.js` : onglets et outils
- `assets/` : logos

## Lancer
Ouvrir `index.html` dans un navigateur, ou activer GitHub Pages (Settings > Pages > branche main).

## Prochaines étapes
Connecter les services externes (images, vidéos, voix, sous-titres, téléchargement, statistiques) via un petit serveur. Ne jamais mettre de clé API dans ce dépôt.
